import React, { Component } from 'react';

class Backtotop extends Component {
    render() {
        return (
            <div className="go-top-area">
                <div className="go-top-wrap">
                    <div className="go-top-btn-wrap">
                        <div className="go-top go-top-btn">
                            <i className="fal fa-angle-double-up" />
                            <i className="fal fa-angle-double-up" />
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Backtotop;