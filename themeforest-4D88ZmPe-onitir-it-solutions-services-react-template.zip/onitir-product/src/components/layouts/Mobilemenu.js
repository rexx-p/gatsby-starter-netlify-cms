import React, { Component } from 'react';

class Mobilemenu extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default Mobilemenu;